F�r die Darstellung einzelner Symbole im mitgelieferten *.mxd sind die Fonts f�r den Basisplan der amtlichen Vermessung "BP-AV" notwendig.

Dies gilt f�r folgende Geodatenprodukte:

- AV MOpublic ESRI Shapefile
- AV ESRI Shapefile
- AV light ESRI Shapefile

Die Fonts k�nnen gratis heruntergeladen werden auf dem Schweizer "Portal der amtlichen Vermessung".

http://www.cadastre.ch/internet/cadastre/de/home/products/BP.html
--> rechts unter "Dokumentation" --> Schrifttyp (Schrift und Symbole)

